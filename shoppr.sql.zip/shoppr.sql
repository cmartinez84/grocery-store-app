-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 10, 2016 at 07:39 AM
-- Server version: 5.6.28
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoppr`
--
CREATE DATABASE IF NOT EXISTS `shoppr` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoppr`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(26, 'produce'),
(27, 'fruit'),
(28, 'organic'),
(29, 'Bread'),
(30, 'Dairy'),
(31, 'Frozen Foods'),
(32, 'Meat'),
(33, 'Beverages'),
(34, 'baking goods'),
(35, 'Deserts'),
(36, 'grains');

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_staging`
--

CREATE TABLE `confirmation_staging` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_serialized` longtext,
  `confirmation_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `funds` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `address`, `password`, `funds`) VALUES
(434, 'bob', 'bob email', 'bob address', 'bob password', 9),
(437, 'strawberry', '', '', '', 0),
(439, 'bath', '', '', '', 0),
(440, 'bath', '', '', '', 0),
(441, 'bath', '', '', '', 0),
(442, 'bath', '', '', '', 0),
(443, 'bath', '', '', '', 0),
(444, 'bath', '', '', '', 0),
(446, 'bob', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart` varchar(255) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `total` int(11) NOT NULL,
  `delivery_date_time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `purchase_quantity` int(11) DEFAULT NULL,
  `inventory` int(11) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `purchase_quantity`, `inventory`, `category`, `photo`) VALUES
(138, 'Apple', 0.98, 0, 23, NULL, '82296-15034-apple.jpg'),
(139, 'Banana', 0.75, 0, 76, NULL, '71077-21339-banana.jpg'),
(141, 'Pear', 0.23, 0, 78, NULL, '60025-pear-08.jpg'),
(143, 'Chuck Beef', 12.97, 0, 4, NULL, '78168-chuck_center_steak.jpg'),
(144, 'Hot Dogs', 1.98, 0, 9, NULL, '35457-Creative-Ideas-to-Serve-Hot-Dogs-4.jpg'),
(145, 'Oreos', 2.98, 0, 6, NULL, '91649-36480-20110719-oreo-taste-test-oreos.jpg'),
(146, 'Yogurt', 3.76, 0, 3, NULL, '52128-yogurt.jpg'),
(147, 'Milk', 2.36, 0, 4, NULL, '76391-milk_blue_bg.jpg'),
(148, 'Granola', 4.97, 0, 12, NULL, '7107-granola.jpg'),
(149, 'unsalted butter', 0.98, 0, 2, NULL, '52042-ttar_unsalted_butter_v.jpg'),
(150, 'Amish Butter', 1.56, 0, 2, NULL, '12411-amish butter.jpg'),
(151, 'cocoa butter', 4.99, 0, 3, NULL, '10689-Cocoa_butter1.jpg'),
(152, 'grass-fed hamburger', 5.98, 0, 3, NULL, '26179-20100129-grass-fed-pre-ground.jpg'),
(153, 'cheetos', 2.98, 0, 2, NULL, '97899-cheetos-girl-in-bath.jpg'),
(154, 'pasta', 0.98, 0, 3, NULL, '65608-pasta.jpg'),
(155, 'applesauce', 1.23, 0, 6, NULL, '45009-Eats_Applesauce.jpg'),
(156, 'sugar', 0.99, 0, 4, NULL, '46738-sugar.jpg'),
(157, 'flour', 1.17, 0, 4, NULL, '67070-flour-2500.jpg'),
(158, 'tequila', 14.99, 0, 72, NULL, '55122-tequila-worm-header.jpg'),
(159, 'pizza', 2.98, 0, 34, NULL, '32750-FrozenPizza.jpg'),
(160, 'Peas', 1.98, 0, 11, NULL, '99845-Frozen-peas.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `products_categories`
--

CREATE TABLE `products_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products_categories`
--

INSERT INTO `products_categories` (`id`, `product_id`, `category_id`) VALUES
(1, 19, 1),
(2, 20, 2),
(3, 20, 3),
(4, 39, 4),
(5, 40, 5),
(6, 40, 6),
(7, 59, 7),
(8, 60, 8),
(9, 60, 9),
(10, 79, 10),
(11, 80, 11),
(12, 80, 12),
(13, 99, 13),
(14, 100, 14),
(15, 100, 15),
(16, 119, 16),
(17, 120, 17),
(18, 120, 18),
(19, 132, 21),
(20, 132, 21),
(21, 132, 21),
(22, 132, 21),
(23, 132, 23),
(24, 132, 23),
(25, 132, 23),
(26, 134, 23),
(27, 134, 23),
(28, 135, 25),
(29, 139, 27),
(30, 139, 28),
(31, 138, 26),
(32, 138, 28),
(33, 141, 26),
(34, 139, 26),
(36, 138, 27),
(37, 141, 27),
(38, 141, 28),
(39, 143, 32),
(40, 144, 32),
(41, 145, 35),
(42, 146, 30),
(43, 147, 30),
(44, 147, 28),
(45, 146, 28),
(46, 143, 28),
(47, 148, 28),
(48, 149, 30),
(49, 150, 30),
(50, 151, 30),
(51, 152, 32),
(52, 153, 36),
(53, 154, 36),
(54, 155, 27),
(55, 156, 34),
(56, 157, 34),
(57, 158, 33),
(58, 159, 31),
(59, 160, 31),
(60, 160, 28),
(61, 150, 28),
(62, 148, 36),
(63, 0, 29),
(64, 0, 29);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `confirmation_staging`
--
ALTER TABLE `confirmation_staging`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `products_categories`
--
ALTER TABLE `products_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `confirmation_staging`
--
ALTER TABLE `confirmation_staging`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=447;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;
--
-- AUTO_INCREMENT for table `products_categories`
--
ALTER TABLE `products_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
