-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Oct 07, 2016 at 09:03 PM
-- Server version: 5.5.42
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoppr`
--
CREATE DATABASE IF NOT EXISTS `shoppr` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoppr`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(26, 'produce'),
(27, 'fruit'),
(28, 'organic'),
(29, 'Bread'),
(30, 'Dairy'),
(31, 'Frozen Foods'),
(32, 'Meat'),
(33, 'Beverages'),
(34, 'baking goods'),
(35, 'Deserts'),
(36, 'grains'),
(37, 'Bugs');

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_staging`
--

CREATE TABLE `confirmation_staging` (
  `id` bigint(20) unsigned NOT NULL,
  `customer_serialized` longtext,
  `confirmation_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `confirmation_staging`
--

INSERT INTO `confirmation_staging` (`id`, `customer_serialized`, `confirmation_code`) VALUES
(1, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:11:"Angie Smith";s:15:"\0Customer\0email";s:18:"avksmit2@gmail.com";s:17:"\0Customer\0address";s:19:"123 Kalama River Rd";s:18:"\0Customer\0password";s:6:"123456";s:15:"\0Customer\0funds";i:0;}', '9aad25'),
(2, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:1:"m";s:15:"\0Customer\0email";s:1:"m";s:17:"\0Customer\0address";s:1:"m";s:18:"\0Customer\0password";s:1:"m";s:15:"\0Customer\0funds";i:0;}', 'm'),
(3, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:4:"Evan";s:15:"\0Customer\0email";s:18:"stewarea@gmail.com";s:17:"\0Customer\0address";s:17:"23409808d jlksdjf";s:18:"\0Customer\0password";s:8:"password";s:15:"\0Customer\0funds";i:0;}', '8a9f55'),
(4, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:12:"Angela Smith";s:15:"\0Customer\0email";s:18:"avksmit2@gmail.com";s:17:"\0Customer\0address";s:19:"123 Kalama River Rd";s:18:"\0Customer\0password";s:6:"123456";s:15:"\0Customer\0funds";i:0;}', 'c30d32'),
(5, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:4:"Evan";s:15:"\0Customer\0email";s:18:"stewarea@gmail.com";s:17:"\0Customer\0address";s:3:"123";s:18:"\0Customer\0password";s:8:"password";s:15:"\0Customer\0funds";i:0;}', '8b9359'),
(6, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:5:"Chris";s:15:"\0Customer\0email";s:24:"cardamomclouds@yahoo.com";s:17:"\0Customer\0address";s:20:"888 white beach lane";s:18:"\0Customer\0password";s:1:"p";s:15:"\0Customer\0funds";i:0;}', 'c255d4'),
(7, 'O:8:"Customer":6:{s:12:"\0Customer\0id";N;s:14:"\0Customer\0name";s:5:"chris";s:15:"\0Customer\0email";s:24:"cardamomclouds@yahoo.com";s:17:"\0Customer\0address";s:10:"3333333333";s:18:"\0Customer\0password";s:6:"333333";s:15:"\0Customer\0funds";i:0;}', '83f7ef');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `funds` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=455 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `address`, `password`, `funds`) VALUES
(432, 'name', 'email', 'address', 'password', 971),
(452, 'Angela Smith', 'avksmit2@gmail.com', '123 Kalama River Rd', '123456', 955),
(453, 'Evan', 'stewarea@gmail.com', '123', 'password', 982),
(454, 'chris', 'cardamomclouds@yahoo.com', '3333333333', '333333', 109507);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart` longtext,
  `order_date` date DEFAULT NULL,
  `total` float(11,2) NOT NULL,
  `delivery_date_time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `cart`, `order_date`, `total`, `delivery_date_time`) VALUES
(1, 437, 'a:3:{i:9;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Apple";s:14:"\0Product\0price";s:4:"0.98";s:26:"\0Product\0purchase_quantity";i:4;s:18:"\0Product\0inventory";i:19;s:14:"\0Product\0photo";s:21:"82296-15034-apple.jpg";s:11:"\0Product\0id";s:3:"138";}i:10;O:7:"Pro', '0000-00-00', 12.00, '1-14-1999'),
(4, 447, 'a:3:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:12:"Amish Butter";s:14:"\0Product\0price";s:4:"1.56";s:26:"\0Product\0purchase_quantity";i:2;s:18:"\0Product\0inventory";i:8;s:14:"\0Product\0photo";s:31:"38790-0884-Roll-Butter-2-lb.jpg";s:11:"\0Product\0id";s:3:"150";}i:4;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Apple";s:14:"\0Product\0price";s:4:"0.98";s:26:"\0Product\0purchase_quantity";i:6;s:18:"\0Product\0inventory";i:13;s:14:"\0Product\0photo";s:21:"82296-15034-apple.jpg";s:11:"\0Product\0id";s:3:"138";}i:5;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Camel";s:14:"\0Product\0price";s:3:"253";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:44;s:14:"\0Product\0photo";s:19:"18181-ATBCamel4.jpg";s:11:"\0Product\0id";s:3:"162";}}', '2016-10-07', 262.00, ' at '),
(5, 447, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(6, 434, 'a:2:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:12:"Amish Butter";s:14:"\0Product\0price";s:4:"1.56";s:26:"\0Product\0purchase_quantity";i:3;s:18:"\0Product\0inventory";i:5;s:14:"\0Product\0photo";s:31:"38790-0884-Roll-Butter-2-lb.jpg";s:11:"\0Product\0id";s:3:"150";}i:1;O:7:"Product":6:{s:13:"\0Product\0name";s:11:"Caterpillar";s:14:"\0Product\0price";s:3:"0.5";s:26:"\0Product\0purchase_quantity";i:2;s:18:"\0Product\0inventory";i:33;s:14:"\0Product\0photo";s:21:"57519-caterpillar.jpg";s:11:"\0Product\0id";s:3:"165";}}', '2016-10-07', 6.00, ' at '),
(7, 450, 'a:2:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Camel";s:14:"\0Product\0price";s:3:"253";s:26:"\0Product\0purchase_quantity";i:3;s:18:"\0Product\0inventory";i:41;s:14:"\0Product\0photo";s:19:"18181-ATBCamel4.jpg";s:11:"\0Product\0id";s:3:"162";}i:1;O:7:"Product":6:{s:13:"\0Product\0name";s:7:"Tequila";s:14:"\0Product\0price";s:5:"14.99";s:26:"\0Product\0purchase_quantity";i:4;s:18:"\0Product\0inventory";i:68;s:14:"\0Product\0photo";s:28:"78553-shot_of_reposado_2.jpg";s:11:"\0Product\0id";s:3:"158";}}', '2016-10-07', 819.00, ' at '),
(8, 452, 'a:6:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Flat Bread";s:14:"\0Product\0price";s:3:"2.5";s:26:"\0Product\0purchase_quantity";i:5;s:18:"\0Product\0inventory";i:25;s:14:"\0Product\0photo";s:32:"54064-Gluten-Free-Flat-Bread.jpg";s:11:"\0Product\0id";s:3:"170";}i:1;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Chuck Beef";s:14:"\0Product\0price";s:5:"12.97";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:4;s:14:"\0Product\0photo";s:28:"78168-chuck_center_steak.jpg";s:11:"\0Product\0id";s:3:"143";}i:2;O:7:"Product":6:{s:13:"\0Product\0name";s:19:"Grass-fed Hamburger";s:14:"\0Product\0price";s:4:"5.98";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:2;s:14:"\0Product\0photo";s:39:"26179-20100129-grass-fed-pre-ground.jpg";s:11:"\0Product\0id";s:3:"152";}i:3;O:7:"Product":6:{s:13:"\0Product\0name";s:18:"Daves Killer Bread";s:14:"\0Product\0price";s:4:"5.23";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:9;s:14:"\0Product\0photo";s:28:"31510-daves-killer-bread.jpg";s:11:"\0Product\0id";s:3:"168";}i:4;O:7:"Product":6:{s:13:"\0Product\0name";s:12:"Amish Butter";s:14:"\0Product\0price";s:4:"1.56";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:4;s:14:"\0Product\0photo";s:31:"38790-0884-Roll-Butter-2-lb.jpg";s:11:"\0Product\0id";s:3:"150";}i:5;O:7:"Product":6:{s:13:"\0Product\0name";s:4:"Ants";s:14:"\0Product\0price";s:4:"0.03";s:26:"\0Product\0purchase_quantity";i:230;s:18:"\0Product\0inventory";i:1420756;s:14:"\0Product\0photo";s:51:"78286-red-wood-ants-communicating.jpg.838x0_q80.jpg";s:11:"\0Product\0id";s:3:"166";}}', '0000-00-00', 45.00, '2016-10-10 at 11:00'),
(9, 432, 'a:6:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:7:"Beetles";s:14:"\0Product\0price";s:4:"0.05";s:26:"\0Product\0purchase_quantity";i:1200;s:18:"\0Product\0inventory";i:34;s:14:"\0Product\0photo";s:19:"62249-prionus2b.jpg";s:11:"\0Product\0id";s:3:"167";}i:1;O:7:"Product":6:{s:13:"\0Product\0name";s:4:"Ants";s:14:"\0Product\0price";s:4:"0.03";s:26:"\0Product\0purchase_quantity";i:1111;s:18:"\0Product\0inventory";i:1419645;s:14:"\0Product\0photo";s:51:"78286-red-wood-ants-communicating.jpg.838x0_q80.jpg";s:11:"\0Product\0id";s:3:"166";}i:2;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Apple";s:14:"\0Product\0price";s:4:"0.98";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:12;s:14:"\0Product\0photo";s:21:"82296-15034-apple.jpg";s:11:"\0Product\0id";s:3:"138";}i:3;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Applesauce";s:14:"\0Product\0price";s:4:"1.23";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:17;s:14:"\0Product\0photo";s:25:"45009-Eats_Applesauce.jpg";s:11:"\0Product\0id";s:3:"155";}i:4;O:7:"Product":6:{s:13:"\0Product\0name";s:4:"Milk";s:14:"\0Product\0price";s:4:"2.36";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:3;s:14:"\0Product\0photo";s:44:"33041-pouring-milk-banners_23-2147506814.jpg";s:11:"\0Product\0id";s:3:"147";}i:5;O:7:"Product":6:{s:13:"\0Product\0name";s:7:"Cheetos";s:14:"\0Product\0price";s:4:"2.98";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:20;s:14:"\0Product\0photo";s:30:"97899-cheetos-girl-in-bath.jpg";s:11:"\0Product\0id";s:3:"153";}}', '2016-10-07', 101.00, '2016-10-24 at 00:00'),
(10, 432, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(11, 453, 'a:3:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:7:"Beetles";s:14:"\0Product\0price";s:4:"0.05";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:33;s:14:"\0Product\0photo";s:19:"62249-prionus2b.jpg";s:11:"\0Product\0id";s:3:"167";}i:1;O:7:"Product":6:{s:13:"\0Product\0name";s:11:"Caterpillar";s:14:"\0Product\0price";s:3:"0.5";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:32;s:14:"\0Product\0photo";s:21:"57519-caterpillar.jpg";s:11:"\0Product\0id";s:3:"165";}i:2;O:7:"Product":6:{s:13:"\0Product\0name";s:4:"Ants";s:14:"\0Product\0price";s:4:"0.03";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:1419644;s:14:"\0Product\0photo";s:51:"78286-red-wood-ants-communicating.jpg.838x0_q80.jpg";s:11:"\0Product\0id";s:3:"166";}}', '0000-00-00', 1.00, '2016-10-03 at 00:34'),
(12, 453, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:11:"Caterpillar";s:14:"\0Product\0price";s:3:"0.5";s:26:"\0Product\0purchase_quantity";i:2;s:18:"\0Product\0inventory";i:30;s:14:"\0Product\0photo";s:21:"57519-caterpillar.jpg";s:11:"\0Product\0id";s:3:"165";}}', '2016-10-07', 1.00, ' at '),
(13, 453, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Applesauce";s:14:"\0Product\0price";s:4:"1.23";s:26:"\0Product\0purchase_quantity";i:3;s:18:"\0Product\0inventory";i:14;s:14:"\0Product\0photo";s:25:"45009-Eats_Applesauce.jpg";s:11:"\0Product\0id";s:3:"155";}}', '2016-10-07', 4.00, ' at '),
(14, 453, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(15, 453, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(16, 453, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:18:"Daves Killer Bread";s:14:"\0Product\0price";s:4:"5.23";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:8;s:14:"\0Product\0photo";s:28:"31510-daves-killer-bread.jpg";s:11:"\0Product\0id";s:3:"168";}}', '2016-10-07', 5.00, ' at '),
(17, 453, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(18, 453, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Apple";s:14:"\0Product\0price";s:4:"0.98";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:11;s:14:"\0Product\0photo";s:21:"82296-15034-apple.jpg";s:11:"\0Product\0id";s:3:"138";}}', '2016-10-07', 1.00, ' at '),
(19, 453, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:12:"Cocoa Butter";s:14:"\0Product\0price";s:4:"4.99";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:5;s:14:"\0Product\0photo";s:23:"10689-Cocoa_butter1.jpg";s:11:"\0Product\0id";s:3:"151";}}', '2016-10-07', 5.00, ' at '),
(20, 453, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Applesauce";s:14:"\0Product\0price";s:4:"1.23";s:26:"\0Product\0purchase_quantity";i:1;s:18:"\0Product\0inventory";i:13;s:14:"\0Product\0photo";s:25:"45009-Eats_Applesauce.jpg";s:11:"\0Product\0id";s:3:"155";}}', '2016-10-07', 1.23, ' at '),
(21, 453, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(22, 432, 'a:0:{}', '2016-10-07', 0.00, ' at '),
(23, 454, 'a:7:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:12:"Amish Butter";s:14:"\0Product\0price";s:4:"1.56";s:26:"\0Product\0purchase_quantity";i:2;s:18:"\0Product\0inventory";i:8;s:14:"\0Product\0photo";s:31:"38790-0884-Roll-Butter-2-lb.jpg";s:11:"\0Product\0id";s:3:"150";}i:1;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Applesauce";s:14:"\0Product\0price";s:4:"1.23";s:26:"\0Product\0purchase_quantity";i:11;s:18:"\0Product\0inventory";i:2;s:14:"\0Product\0photo";s:25:"45009-Eats_Applesauce.jpg";s:11:"\0Product\0id";s:3:"155";}i:2;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Chuck Beef";s:14:"\0Product\0price";s:5:"12.97";s:26:"\0Product\0purchase_quantity";i:6;s:18:"\0Product\0inventory";i:3;s:14:"\0Product\0photo";s:28:"78168-chuck_center_steak.jpg";s:11:"\0Product\0id";s:3:"143";}i:3;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Flat Bread";s:14:"\0Product\0price";s:3:"2.5";s:26:"\0Product\0purchase_quantity";i:3;s:18:"\0Product\0inventory";i:22;s:14:"\0Product\0photo";s:32:"54064-Gluten-Free-Flat-Bread.jpg";s:11:"\0Product\0id";s:3:"170";}i:4;O:7:"Product":6:{s:13:"\0Product\0name";s:13:"Patron Silver";s:14:"\0Product\0price";s:2:"44";s:26:"\0Product\0purchase_quantity";i:33;s:18:"\0Product\0inventory";i:0;s:14:"\0Product\0photo";s:16:"15061-patron.jpg";s:11:"\0Product\0id";s:3:"174";}i:5;O:7:"Product":6:{s:13:"\0Product\0name";s:11:"Nopales 1lb";s:14:"\0Product\0price";s:1:"1";s:26:"\0Product\0purchase_quantity";i:33;s:18:"\0Product\0inventory";i:389;s:14:"\0Product\0photo";s:17:"99948-nopales.jpg";s:11:"\0Product\0id";s:3:"180";}i:6;O:7:"Product":6:{s:13:"\0Product\0name";s:18:"Daves Killer Bread";s:14:"\0Product\0price";s:4:"5.23";s:26:"\0Product\0purchase_quantity";i:2;s:18:"\0Product\0inventory";i:6;s:14:"\0Product\0photo";s:28:"31510-daves-killer-bread.jpg";s:11:"\0Product\0id";s:3:"168";}}', '0000-00-00', 1.00, '1111-11-11 at 11:11'),
(24, 454, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:10:"Applesauce";s:14:"\0Product\0price";s:4:"1.23";s:26:"\0Product\0purchase_quantity";i:3;s:18:"\0Product\0inventory";i:1;s:14:"\0Product\0photo";s:25:"45009-Eats_Applesauce.jpg";s:11:"\0Product\0id";s:3:"155";}}', '2016-10-07', 3.69, ' at '),
(25, 454, 'a:1:{i:0;O:7:"Product":6:{s:13:"\0Product\0name";s:5:"Apple";s:14:"\0Product\0price";s:4:"0.98";s:26:"\0Product\0purchase_quantity";i:3;s:18:"\0Product\0inventory";i:8;s:14:"\0Product\0photo";s:21:"82296-15034-apple.jpg";s:11:"\0Product\0id";s:3:"138";}}', '2016-10-07', 2.94, ' at ');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `purchase_quantity` int(11) DEFAULT NULL,
  `inventory` int(11) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `purchase_quantity`, `inventory`, `category`, `photo`) VALUES
(138, 'Apple', 0.98, 0, 8, NULL, '82296-15034-apple.jpg'),
(139, 'Banana', 0.75, 0, 73, NULL, '71077-21339-banana.jpg'),
(141, 'Pear', 0.23, 0, 78, NULL, '60025-pear-08.jpg'),
(143, 'Chuck Beef', 12.97, 0, 3, NULL, '78168-chuck_center_steak.jpg'),
(144, 'Hot Dogs', 1.98, 0, 9, NULL, '35457-Creative-Ideas-to-Serve-Hot-Dogs-4.jpg'),
(145, 'Oreos', 2.98, 0, 6, NULL, '91649-36480-20110719-oreo-taste-test-oreos.jpg'),
(146, 'Yogurt', 3.76, 0, 9, NULL, '52128-yogurt.jpg'),
(147, 'Milk', 2.36, 0, 3, NULL, '33041-pouring-milk-banners_23-2147506814.jpg'),
(148, 'Granola', 4.97, 0, 9, NULL, '7107-granola.jpg'),
(149, 'Unsalted Butter', 0.98, 0, 12, NULL, '52042-ttar_unsalted_butter_v.jpg'),
(150, 'Amish Butter', 1.56, 0, 8, NULL, '38790-0884-Roll-Butter-2-lb.jpg'),
(151, 'Cocoa Butter', 4.99, 0, 5, NULL, '10689-Cocoa_butter1.jpg'),
(152, 'Grass-fed Hamburger', 5.98, 0, 21, NULL, '26179-20100129-grass-fed-pre-ground.jpg'),
(153, 'Cheetos', 2.98, 0, 20, NULL, '97899-cheetos-girl-in-bath.jpg'),
(154, 'Pasta', 0.98, 0, 13, NULL, '67833-pasta.jpg'),
(155, 'Applesauce', 1.23, 0, 1, NULL, '45009-Eats_Applesauce.jpg'),
(156, 'Sugar', 0.99, 0, 14, NULL, '46738-sugar.jpg'),
(157, 'Flour', 1.17, 0, 15, NULL, '67070-flour-2500.jpg'),
(158, 'Tequila', 14.99, 0, 68, NULL, '78553-shot_of_reposado_2.jpg'),
(159, 'Pizza', 2.98, 0, 34, NULL, '46111-pizza.jpg'),
(160, 'Peas', 1.98, 0, 11, NULL, '37238-frozen-vegetable-recall.jpg'),
(161, 'Water', 400, 0, 1, NULL, '59068-water.jpg'),
(162, 'Camel', 253, 0, 41, NULL, '18181-ATBCamel4.jpg'),
(163, 'Sand', 0.01, 0, 105829, NULL, '49335-sand.JPG'),
(164, 'Wonder Bread', 1.5, 0, 30, NULL, '32510-wonder-classic-white-sandwich-bread-24-oz_4734098.jpg'),
(165, 'Caterpillar', 0.5, 0, 30, NULL, '57519-caterpillar.jpg'),
(166, 'Ants', 0.03, 0, 1419644, NULL, '78286-red-wood-ants-communicating.jpg.838x0_q80.jpg'),
(167, 'Beetles', 0.05, 0, 33, NULL, '62249-prionus2b.jpg'),
(168, 'Daves Killer Bread', 5.23, 0, 6, NULL, '31510-daves-killer-bread.jpg'),
(169, 'tortillas', 1.23, 0, 20, NULL, '60847-flour-tortilla.jpg'),
(170, 'Flat Bread', 2.5, 0, 22, NULL, '54064-Gluten-Free-Flat-Bread.jpg'),
(171, 'Lamb Shoulder', 11.88, 0, 4, NULL, '73126-lambshoulder.jpg'),
(172, 'Olemca Altos Tequila', 17.99, 0, 33, NULL, ''),
(173, 'Gran Centenario', 33, 0, 22, NULL, '93518-grancentenario.jpg'),
(174, 'Patron Silver', 44, 0, 0, NULL, '15061-patron.jpg'),
(175, 'Tapatio (Tequila)', 39, 0, 44, NULL, '50213-tapatio-blanco_6161_r2.jpg'),
(176, 'Milagro Silver', 29, 0, 11, NULL, '13371-milagrosilver.jpg'),
(177, 'Cazadores', 22.22, 0, 2, NULL, '15112-cazadores.jpg'),
(178, 'Herradura', 29, 0, 2, NULL, '12601-Herradura.jpg'),
(179, 'Espolon Blanco', 27.99, 0, 44, NULL, '43232-espolon.jpg'),
(180, 'Nopales 1lb', 1, 0, 389, NULL, '99948-nopales.jpg'),
(181, 'Armadillo Meat', 4.99, 0, 25, NULL, '70237-armadilo.jpg'),
(182, 'Prickly Pears', 1, 0, 57, NULL, '25834-pricklypears.jpg'),
(183, 'Snake Meat', 2, 0, 33, NULL, '38738-snakemeat.jpg'),
(184, 'GF Flour', 33.33, 0, 32, NULL, '27756-gfflour.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `products_categories`
--

CREATE TABLE `products_categories` (
  `id` bigint(20) unsigned NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products_categories`
--

INSERT INTO `products_categories` (`id`, `product_id`, `category_id`) VALUES
(1, 19, 1),
(2, 20, 2),
(3, 20, 3),
(4, 39, 4),
(5, 40, 5),
(6, 40, 6),
(7, 59, 7),
(8, 60, 8),
(9, 60, 9),
(10, 79, 10),
(11, 80, 11),
(12, 80, 12),
(13, 99, 13),
(14, 100, 14),
(15, 100, 15),
(16, 119, 16),
(17, 120, 17),
(18, 120, 18),
(19, 132, 21),
(20, 132, 21),
(21, 132, 21),
(22, 132, 21),
(23, 132, 23),
(24, 132, 23),
(25, 132, 23),
(26, 134, 23),
(27, 134, 23),
(28, 135, 25),
(29, 139, 27),
(30, 139, 28),
(31, 138, 26),
(32, 138, 28),
(33, 141, 26),
(34, 139, 26),
(36, 138, 27),
(37, 141, 27),
(38, 141, 28),
(39, 143, 32),
(40, 144, 32),
(41, 145, 35),
(42, 146, 30),
(43, 147, 30),
(44, 147, 28),
(45, 146, 28),
(46, 143, 28),
(47, 148, 28),
(48, 149, 30),
(49, 150, 30),
(50, 151, 30),
(51, 152, 32),
(52, 153, 36),
(53, 154, 36),
(54, 155, 27),
(55, 156, 34),
(56, 157, 34),
(57, 158, 33),
(58, 159, 31),
(59, 160, 31),
(60, 160, 28),
(61, 150, 28),
(62, 148, 36),
(63, 0, 29),
(64, 0, 29),
(65, 161, 35),
(66, 162, 35),
(67, 163, 35),
(68, 164, 29),
(69, 165, 37),
(70, 166, 37),
(71, 167, 37),
(72, 0, 29),
(73, 168, 29),
(74, 169, 29),
(75, 170, 29),
(76, 170, 28),
(77, 167, 28),
(78, 166, 28),
(79, 162, 28),
(80, 165, 28),
(81, 151, 28),
(82, 161, 28),
(83, 0, 33),
(84, 0, 33),
(85, 171, 32),
(86, 172, 33),
(87, 173, 33),
(88, 174, 33),
(89, 175, 33),
(90, 176, 33),
(91, 177, 33),
(92, 178, 33),
(93, 179, 33),
(94, 180, 35),
(95, 181, 35),
(96, 182, 35),
(97, 183, 35),
(98, 184, 34),
(99, 155, 28);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `confirmation_staging`
--
ALTER TABLE `confirmation_staging`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `products_categories`
--
ALTER TABLE `products_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `confirmation_staging`
--
ALTER TABLE `confirmation_staging`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=455;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=185;
--
-- AUTO_INCREMENT for table `products_categories`
--
ALTER TABLE `products_categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
